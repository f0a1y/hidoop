package map;

public interface MapReduce extends Mapper, Reducer {
}
